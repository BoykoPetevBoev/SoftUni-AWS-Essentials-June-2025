"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/saveCatHandler.ts
var saveCatHandler_exports = {};
__export(saveCatHandler_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(saveCatHandler_exports);
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_client_sns = require("@aws-sdk/client-sns");

// node_modules/uuid/dist/esm/stringify.js
var byteToHex = [];
for (let i = 0; i < 256; ++i) {
  byteToHex.push((i + 256).toString(16).slice(1));
}
function unsafeStringify(arr, offset = 0) {
  return (byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + "-" + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + "-" + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + "-" + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + "-" + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]]).toLowerCase();
}

// node_modules/uuid/dist/esm/rng.js
var import_crypto = require("crypto");
var rnds8Pool = new Uint8Array(256);
var poolPtr = rnds8Pool.length;
function rng() {
  if (poolPtr > rnds8Pool.length - 16) {
    (0, import_crypto.randomFillSync)(rnds8Pool);
    poolPtr = 0;
  }
  return rnds8Pool.slice(poolPtr, poolPtr += 16);
}

// node_modules/uuid/dist/esm/native.js
var import_crypto2 = require("crypto");
var native_default = { randomUUID: import_crypto2.randomUUID };

// node_modules/uuid/dist/esm/v4.js
function v4(options, buf, offset) {
  if (native_default.randomUUID && !buf && !options) {
    return native_default.randomUUID();
  }
  options = options || {};
  const rnds = options.random ?? options.rng?.() ?? rng();
  if (rnds.length < 16) {
    throw new Error("Random bytes length must be >= 16");
  }
  rnds[6] = rnds[6] & 15 | 64;
  rnds[8] = rnds[8] & 63 | 128;
  if (buf) {
    offset = offset || 0;
    if (offset < 0 || offset + 16 > buf.length) {
      throw new RangeError(`UUID byte range ${offset}:${offset + 15} is out of buffer bounds`);
    }
    for (let i = 0; i < 16; ++i) {
      buf[offset + i] = rnds[i];
    }
    return buf;
  }
  return unsafeStringify(rnds);
}
var v4_default = v4;

// src/saveCatHandler.ts
var snsClient = new import_client_sns.SNSClient();
var ddbClient = new import_client_dynamodb.DynamoDBClient();
var handler = async (event) => {
  try {
    console.log(JSON.stringify(event));
    const topicArn = process.env.TOPIC_ARN;
    const tableName = process.env.TABLE_NAME;
    if (!topicArn || !tableName) {
      throw new Error("Missing required environment variables: TOPIC_ARN or TABLE_NAME");
    }
    const data = JSON.parse(event.body || "{}");
    if (!data.catId || !data.savedUrl) {
      return {
        statusCode: 400,
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
          "Access-Control-Allow-Methods": "OPTIONS,POST,GET",
          "Access-Control-Allow-Credentials": "true"
        },
        body: JSON.stringify({ error: "Missing required fields: catId and savedUrl" })
      };
    }
    const uuidData = v4_default();
    await ddbClient.send(new import_client_dynamodb.PutItemCommand({
      TableName: tableName,
      Item: {
        PK: { S: `CAT#${uuidData}` },
        SK: { S: `METADATA#${uuidData}` },
        uuid: { S: uuidData },
        catId: { S: data.catId },
        savedUrl: { S: data.savedUrl },
        savedAt: { S: (/* @__PURE__ */ new Date()).toISOString() }
      }
    }));
    await snsClient.send(new import_client_sns.PublishCommand({
      TopicArn: topicArn,
      Subject: "\u{1F431} New Favorite Cat Saved!",
      Message: `\u{1F389} Lydia has a new favorite cat!

            \u{1F408} Cat ID: ${data.catId}
            \u{1F517} Image URL: ${data.savedUrl}
            \u23F0 Saved at: ${(/* @__PURE__ */ new Date()).toISOString()}
            
            View the cat: ${data.savedUrl}
            
            This cat is now saved as Lydia's favorite! \u{1F38A}`
    }));
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
        "Access-Control-Allow-Methods": "OPTIONS,POST,GET",
        "Access-Control-Allow-Credentials": "true"
      },
      body: JSON.stringify({
        message: "Cat saved successfully",
        catId: data.catId,
        savedUrl: data.savedUrl,
        uuid: uuidData
      })
    };
  } catch (error) {
    console.error("Error in saveCatHandler:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
        "Access-Control-Allow-Methods": "OPTIONS,POST,GET",
        "Access-Control-Allow-Credentials": "true"
      },
      body: JSON.stringify({ error: "Internal server error", message: errorMessage })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
