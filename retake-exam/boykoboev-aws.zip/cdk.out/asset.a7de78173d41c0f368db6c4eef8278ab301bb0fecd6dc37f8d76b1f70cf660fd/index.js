"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/saveCatHandler.ts
var saveCatHandler_exports = {};
__export(saveCatHandler_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(saveCatHandler_exports);
var import_client_sns = require("@aws-sdk/client-sns");
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var snsClient = new import_client_sns.SNSClient();
var ddbClient = new import_client_dynamodb.DynamoDBClient();
var handler = async (event) => {
  console.log(JSON.stringify(event));
  const topicArn = process.env.TOPIC_ARN;
  const tableName = process.env.TABLE_NAME;
  const data = JSON.parse(event.body);
  await ddbClient.send(new import_client_dynamodb.PutItemCommand({
    TableName: tableName,
    Item: {
      PK: { S: `EXAM#${uuidData}` },
      SK: { S: `METADATA#${uuidData}` },
      catId: { BOOL: data.catId },
      savedUrl: { BOOL: data.savedUrl }
    }
  }));
  await snsClient.send(new import_client_sns.PublishCommand({
    TopicArn: topicArn,
    Subject: "Retake Exam",
    Message: JSON.stringify(data)
  }));
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
